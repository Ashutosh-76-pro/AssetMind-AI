import streamlit as st

st.set_page_config(page_title="KnowledgeForge-AI")

st.title("KnowledgeForge-AI")
st.write("AI-powered Industrial Knowledge Intelligence Platform")

uploaded_file = st.file_uploader("Upload a PDF", type=["pdf"])

question = st.text_input("Ask a question about your document")

if st.button("Submit"):
    if question:
        st.success("Demo response: Integrate Gemini + FAISS here for full RAG functionality.")
    else:
        st.warning("Please enter a question.")
